var searchData=
[
  ['init',['init',['../classFreeIMU.html#ad1e754f18d487fe4a96a1b06785f48e6',1,'FreeIMU::init()'],['../classFreeIMU.html#ae425675f021e7b51fd6b585b5a1d45c1',1,'FreeIMU::init(bool fastmode)'],['../classFreeIMU.html#a2c01b69cc66a7cee2a173c40ffb498dc',1,'FreeIMU::init(int acc_addr, int gyro_addr, bool fastmode)']]],
  ['invsqrt',['invSqrt',['../FreeIMU_8cpp.html#ae275609337974b29c58aae13d82bf3a9',1,'invSqrt(float number):&#160;FreeIMU.cpp'],['../FreeIMU_8h.html#ae275609337974b29c58aae13d82bf3a9',1,'invSqrt(float number):&#160;FreeIMU.cpp']]],
  ['is_5f6dom',['IS_6DOM',['../FreeIMU_8h.html#a095538a7cfef8adf44dbe94c29868a1c',1,'FreeIMU.h']]],
  ['is_5f9dom',['IS_9DOM',['../FreeIMU_8h.html#a487f99a8f9cc3374374f499d18869cf8',1,'FreeIMU.h']]]
];
