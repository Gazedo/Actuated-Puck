Teensy ++
Original Design by Mark Gross
Modified Design by Tamir Emran (http://tae09.blogspot.com)


Teensy 2.0
Original Design by Clint Fisher
Modified Design by Tamir Emran (http://tae09.blogspot.com)


Design Notes:

1) Vias are set to 0.04" drill size, and 0.074" pad size. Drill size should be no smaller than 0.038" to fit standard pins. 
2) Two smaller vias on Teensy ++ designed for wires, not for pins. Any attempt to manipulate them for usage with pins will result in a mismatch with the original Teensy ++ Footprint.
3) Licensed Under Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

